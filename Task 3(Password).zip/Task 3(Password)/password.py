import re

def password_strength(password):
    strength_criteria = {
        "length": len(password) >= 8,
        "uppercase": bool(re.search(r"[A-Z]", password)),
        "lowercase": bool(re.search(r"[a-z]", password)),
        "digits": bool(re.search(r"[0-9]", password)),
        "special_chars": bool(re.search(r"[!@#$%^&*(),.?\":{}|<>]", password)),
    }

    score = sum(strength_criteria.values())
    strength_levels = {
        0: "Very Weak",
        1: "Weak",
        2: "Moderate",
        3: "Strong",
        4: "Very Strong",
        5: "Excellent",
    }
    
    feedback = []
    if not strength_criteria["length"]:
        feedback.append("Password should be at least 8 characters long.")
    if not strength_criteria["uppercase"]:
        feedback.append("Password should include at least one uppercase letter.")
    if not strength_criteria["lowercase"]:
        feedback.append("Password should include at least one lowercase letter.")
    if not strength_criteria["digits"]:
        feedback.append("Password should include at least one digit.")
    if not strength_criteria["special_chars"]:
        feedback.append("Password should include at least one special character.")

    strength = strength_levels[score]
    return strength, feedback

def main():
    password = input("Enter a password to evaluate its strength: ")
    strength, feedback = password_strength(password)
    
    print(f"Password Strength: {strength}")
    if feedback:
        print("Feedback:")
        for comment in feedback:
            print(f"- {comment}")

if __name__ == "__main__":
    main()
